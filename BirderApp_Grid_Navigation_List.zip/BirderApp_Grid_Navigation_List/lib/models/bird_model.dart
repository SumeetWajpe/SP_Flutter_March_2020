class BirdModel {
  final int id;
  final String name;
  final String scientificName;
  final String imageUrl;

  BirdModel({this.id, this.name, this.scientificName, this.imageUrl});
}
