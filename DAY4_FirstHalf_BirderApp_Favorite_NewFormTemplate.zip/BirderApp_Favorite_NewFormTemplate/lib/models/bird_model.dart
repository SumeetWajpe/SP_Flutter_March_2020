class BirdModel {
  final int id;
  final String name;
  final String scientificName;
  final String imageUrl;
  final String info;

  BirdModel(
      {this.id, this.name, this.scientificName, this.imageUrl, this.info});
}
