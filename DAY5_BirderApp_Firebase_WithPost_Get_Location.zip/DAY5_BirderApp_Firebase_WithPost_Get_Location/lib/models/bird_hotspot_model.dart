class HotSpotModel {
  final double latitude;
  final double longitude;
  final String name;

  HotSpotModel({this.latitude, this.longitude, this.name});
}
