class BirdCategoryModel {
  final int id;
  final String name;
  final String imageUrl;

  BirdCategoryModel({this.id, this.name, this.imageUrl});
}
