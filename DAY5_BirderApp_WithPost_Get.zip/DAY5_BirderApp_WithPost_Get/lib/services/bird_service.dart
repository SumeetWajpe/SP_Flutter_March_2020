import 'dart:convert';

import '../models/bird_model.dart';
import 'package:http/http.dart' as http;

class BirdService {
  static Future<void> addBirdToFirebaseDB(BirdModel newBird) async {
    // http pkg
    // http.post(url,datatoadded)
    try {
      const _domainString =
          'fbirderappsumeet-default-rtdb.europe-west1.firebasedatabase.app';
      const _urlString = "birds.json";
      // do not hardcode the url, u can accept url as parameter
      Uri url = Uri.https(_domainString, _urlString);
      http.post(url,
          body: json.encode({
            "id": newBird.id,
            "name": newBird.name,
            "scientificName": newBird.scientificName,
            "imageUrl": newBird.imageUrl,
            "info": newBird.info
          }));

      // check the response from http.post()
      // if response.statusCode == 200
      // return "success"
    } catch (error) {
      // throw (error);
      print(error);
    }
  }

  static Future<List<BirdModel>> fetchBirds() async {
    final List<BirdModel> loadedBirds = [];
    try {
      const _domainString =
          'fbirderappsumeet-default-rtdb.europe-west1.firebasedatabase.app';
      const _urlString = "birds.json";
      Uri url = Uri.https(_domainString, _urlString);
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final extractedData =
            json.decode(response.body) as Map<String, dynamic>;

        extractedData.forEach((birdGenId, eachBird) {
          loadedBirds.add(BirdModel.fromJSON(
              eachBird)); //extract the data and convert to strongly typed model
        });
      }
      return loadedBirds;
    } catch (error) {}
  }
}
