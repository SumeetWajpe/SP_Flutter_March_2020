import 'package:flutter/cupertino.dart';

class MenuItem {
  final IconData icon;
  final String name;
  final String route;

  MenuItem({this.icon, this.name, this.route});
}
