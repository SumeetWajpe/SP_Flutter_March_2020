// TODO 1: Write a main() method to execute your tests
// TODO 2: Create a group with the name of the class

// TODO 3.1: Write a test that the TimeHelper should return Morning
// TODO 3.2: Write a test that the TimeHelper should return Afternoon
// TODO 3.3: Write a test that the TimeHelper should return Evening
// TODO 3.4: Write a test that the TimeHelper should return Night

import 'package:flutter_test/flutter_test.dart';

main() {
  test("Test true to be true", () {
    // Arrange
    bool expectedBoolValue = true;
    // Act

    //Assert
    expect(expectedBoolValue, true);
  });
}
